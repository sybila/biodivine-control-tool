Aeon Compute Engine

The Aeon Compute Engine powers the Aeon tool, which can be found at http://biodivine.fi.muni.cz/aeon/.

Quick Start

1. Running the Compute Engine
- If you've downloaded the pre-built binary, simply navigate to the folder where you unzipped it and run the compute-engine file.
- Once the engine starts, it will output the current address and port where it is running.
- By default, the engine runs on localhost:8000, which is compatible with the online client.

2. Connecting to the Engine
- After the engine starts, you can connect immediately using the default address (localhost:8000).
- If you'd like to run the engine on a different address or port, you can configure it using the AEON_ADDR and AEON_PORT environmental variables.
- Make sure to input the same address and port into the online client when connecting.

Troubleshooting

Fixing Permissions (If Needed)
If you encounter a permission error while running the compute-engine file, you can resolve it with the following command in your terminal:

    chmod +x compute-engine

After updating the permissions, try running the file again.

System Requirements

Operating System
- Linux (x86-64 architecture)

Additional Information
For more detailed instructions and information about the Aeon tool, visit the official website: http://biodivine.fi.muni.cz/aeon/
