# Aeon Compute Engine

This is a compute engine for the Aeon tool (http://biodivine.fi.muni.cz/aeon/).

If you downloaded a pre-built binary, you can just run compute-engine file to start the engine. The binary will output
current address and port on which the compute engine is running. Later, when performing actions, there
will some additional logging output. The engine will automatically run on localhost:8000 which is the 
default setting for the online client. Hence once the engine is running, you should be able to 
connect immediately.

If for some reason, you can't run the engine on `localhost:8000`, you can configure the address and port
using environmental variables `AEON_ADDR` and `AEON_PORT`. Then you have to input this address and port 
also into the online client when connecting. 

More information about the operation of Aeon can be found at https://biodivine.fi.muni.cz/aeon/

