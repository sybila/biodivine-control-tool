Aeon Compute Engine

The Aeon Compute Engine powers the Aeon tool, which can be found at http://biodivine.fi.muni.cz/aeon/.

Quick Start

1. **Running the Compute Engine**
   - After unzipping the pre-built binary, navigate to the folder where it is located and run the `compute-engine` file.
   
2. **Bypass Security Warning**
   - macOS may block the execution of the file if it is from an unidentified developer. To bypass this:
     - Open **System Preferences** and go to **Security & Privacy**.
     - Under the **General** tab, look for a message saying that the `compute-engine` was blocked.
     - Click **Open Anyway**, and the Compute Engine should run.

3. **Connecting to the Engine**
   - Once the engine starts, it will output the current address and port where it is running. By default, it runs on `localhost:8000`, which is compatible with the online client.
   - If you'd like to run the engine on a different address or port, configure it using the `AEON_ADDR` and `AEON_PORT` environment variables.
   - Make sure to input the same address and port into the online client when connecting.


Troubleshooting

Fixing Permissions (If Needed)
If you encounter a permission error while running the compute-engine file, you can resolve it with the following command in your terminal:

    chmod +x compute-engine

After updating the permissions, try running the file again.

System Requirements

Operating System 
- macOS (x86-64 - Intel-based)

Additional Information
For more detailed instructions and information about the Aeon tool, visit the official website: https://biodivine.fi.muni.cz/aeon/