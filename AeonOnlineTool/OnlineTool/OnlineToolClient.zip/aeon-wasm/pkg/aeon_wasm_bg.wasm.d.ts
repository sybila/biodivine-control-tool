/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function check_model(a: number, b: number, c: number): void;
export function sbml_to_aeon(a: number, b: number, c: number): void;
export function aeon_to_sbml(a: number, b: number, c: number): void;
export function aeon_to_sbml_instantiated(a: number, b: number, c: number): void;
export function bnet_to_aeon(a: number, b: number, c: number): void;
export function aeon_to_bnet(a: number, b: number, c: number): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
export function __wbindgen_free(a: number, b: number, c: number): void;
